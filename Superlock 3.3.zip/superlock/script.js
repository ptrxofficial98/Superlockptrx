// ===== MAIN SCRIPT =====

// Tab switcher
function sw(tab) {
  document.querySelectorAll('.card').forEach(c => c.classList.remove('active'));
  document.querySelectorAll('.nav .btn').forEach(b => b.classList.remove('active'));

  const cardId = 'c' + tab.charAt(0).toUpperCase() + tab.slice(1);
  const card = document.getElementById(cardId);
  if (card) card.classList.add('active');

  const tabMap = { lock:0, font:1, calc:2, ai:3, chat:4, dev:5, phone:6 };
  const idx = tabMap[tab];
  const btns = document.querySelectorAll('.nav .btn');
  if (idx !== undefined && btns[idx]) btns[idx].classList.add('active');

  // Trigger lazy inits
  if (tab === 'chat') renderPublicChat();
  if (tab === 'font') prevFont();
}

// Toast notification
let toastTimer;
function showToast(msg, duration = 2500) {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), duration);
}

// Prevent accidental page close
window.addEventListener('beforeunload', e => {
  const sess = localStorage.getItem('sl_session');
  if (sess) { e.preventDefault(); e.returnValue = ''; }
});
