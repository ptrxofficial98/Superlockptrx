// ===== CALCULATOR MODULE =====
let calcExpr = '';

const calcButtons = [
  { label:'C', cls:'clr', action:'clear' },
  { label:'⌫', cls:'clr', action:'del' },
  { label:'%', cls:'op', action:'%' },
  { label:'÷', cls:'op', action:'/' },
  { label:'7', action:'7' }, { label:'8', action:'8' }, { label:'9', action:'9' },
  { label:'×', cls:'op', action:'*' },
  { label:'4', action:'4' }, { label:'5', action:'5' }, { label:'6', action:'6' },
  { label:'−', cls:'op', action:'-' },
  { label:'1', action:'1' }, { label:'2', action:'2' }, { label:'3', action:'3' },
  { label:'+', cls:'op', action:'+' },
  { label:'±', action:'negate' }, { label:'0', action:'0' }, { label:'.', action:'.' },
  { label:'=', cls:'eq', action:'=' },
];

function buildCalc() {
  const grid = document.getElementById('calcGrid');
  calcButtons.forEach(b => {
    const btn = document.createElement('button');
    btn.className = 'calc-btn ' + (b.cls || '');
    btn.textContent = b.label;
    btn.onclick = () => calcAction(b.action);
    grid.appendChild(btn);
  });
}

function calcAction(a) {
  const screen = document.getElementById('calcScreen');
  if (a === 'clear') { calcExpr = ''; screen.value = '0'; return; }
  if (a === 'del') {
    calcExpr = calcExpr.slice(0,-1);
    screen.value = calcExpr || '0';
    return;
  }
  if (a === 'negate') {
    try {
      const v = parseFloat(eval(calcExpr||'0'));
      calcExpr = String(-v);
      screen.value = calcExpr;
    } catch {}
    return;
  }
  if (a === '=') {
    try {
      const result = Function('"use strict"; return (' + calcExpr + ')')();
      screen.value = parseFloat(result.toFixed(10));
      calcExpr = String(result);
    } catch { screen.value = 'Error'; calcExpr = ''; }
    return;
  }
  if (a === '%') {
    try {
      const result = Function('"use strict"; return (' + calcExpr + '/100)')();
      screen.value = parseFloat(result.toFixed(10));
      calcExpr = String(result);
    } catch { screen.value = 'Error'; calcExpr = ''; }
    return;
  }
  calcExpr += a;
  screen.value = calcExpr;
}

// Keyboard support
document.addEventListener('keydown', (e) => {
  if (document.getElementById('cCalc')?.classList.contains('active')) {
    if ('0123456789.+-*/'.includes(e.key)) calcAction(e.key);
    if (e.key === 'Enter' || e.key === '=') calcAction('=');
    if (e.key === 'Backspace') calcAction('del');
    if (e.key === 'Escape') calcAction('clear');
  }
});

document.addEventListener('DOMContentLoaded', buildCalc);
