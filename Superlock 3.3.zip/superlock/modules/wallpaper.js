// ===== WALLPAPER MODULE =====
const WALLPAPERS = [
  { label:'Aurora',   url:'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=1920' },
  { label:'Galaxy',   url:'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=1920' },
  { label:'Ocean',    url:'https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=1920' },
  { label:'Forest',   url:'https://images.unsplash.com/photo-1448375240586-882707db888b?w=1920' },
  { label:'City',     url:'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=1920' },
  { label:'Abstract', url:'https://images.unsplash.com/photo-1518020382113-a7e8fc38eac9?w=1920' },
  { label:'Mountains',url:'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1920' },
  { label:'Desert',   url:'https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=1920' },
  { label:'Dark',     url:'https://images.unsplash.com/photo-1475274047050-1d0c0975c63e?w=1920' },
];

function buildWallpaperGrid() {
  const grid = document.getElementById('wallpaperGrid');
  if (!grid) return;
  grid.innerHTML = '';
  WALLPAPERS.forEach(wp => {
    const div = document.createElement('div');
    div.className = 'wp-thumb';
    div.title = wp.label;
    div.innerHTML = `<img src="${wp.url}&w=200" loading="lazy" alt="${wp.label}">`;
    div.onclick = () => {
      document.querySelectorAll('.wp-thumb').forEach(t => t.classList.remove('selected'));
      div.classList.add('selected');
      applyWallpaper(wp.url);
      saveWallpaper(wp.url);
    };
    grid.appendChild(div);
  });
}

function applyWallpaper(url) {
  const ov = document.getElementById('wallpaperOverlay');
  if (!ov) return;
  if (!url) { ov.style.backgroundImage = ''; ov.style.opacity = '0'; return; }
  ov.style.backgroundImage = `url('${url}')`;
  ov.style.opacity = '0.3';
}

function setCustomWallpaper() {
  const url = document.getElementById('customWallpaper').value.trim();
  if (!url) return showToast('⚠️ Masukkan URL gambar!');
  applyWallpaper(url);
  saveWallpaper(url);
  closeWallpaperModal();
  showToast('✅ Wallpaper diterapkan!');
}

function saveWallpaper(url) {
  const sess = JSON.parse(localStorage.getItem('sl_session') || '{}');
  if (!sess.email) return;
  const db = JSON.parse(localStorage.getItem('sl_users') || '{}');
  if (db[sess.email]) { db[sess.email].wallpaper = url; localStorage.setItem('sl_users', JSON.stringify(db)); }
}

function openWallpaperModal() {
  const modal = document.getElementById('wallpaperModal');
  modal.style.display = 'flex';
  buildWallpaperGrid();
}

function closeWallpaperModal() {
  document.getElementById('wallpaperModal').style.display = 'none';
}

// Close modal on backdrop click
document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('wallpaperModal');
  if (modal) modal.addEventListener('click', e => { if(e.target===modal) closeWallpaperModal(); });
});
