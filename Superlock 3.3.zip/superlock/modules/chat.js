// ===== PUBLIC CHAT MODULE =====
// Chat antar user Superlock - disimpan di localStorage (shared key)
const CHAT_KEY = 'sl_public_chat';

function getPublicMessages() {
  return JSON.parse(localStorage.getItem(CHAT_KEY) || '[]');
}

function savePublicMessages(msgs) {
  // Batasi 200 pesan terakhir
  if (msgs.length > 200) msgs = msgs.slice(-200);
  localStorage.setItem(CHAT_KEY, JSON.stringify(msgs));
}

function renderPublicChat() {
  const msgs = getPublicMessages();
  const box  = document.getElementById('publicChatBox');
  const sess = JSON.parse(localStorage.getItem('sl_session') || '{}');
  box.innerHTML = '';

  if (msgs.length === 0) {
    box.innerHTML = '<div class="msg msg-ai">💬 Belum ada pesan. Jadilah yang pertama!</div>';
    return;
  }

  msgs.forEach(m => {
    const el = document.createElement('div');
    const isMe = m.email === sess.email;
    el.className = `msg ${isMe ? 'msg-user' : 'msg-ai'}`;
    el.innerHTML = isMe
      ? `${escapeHtml(m.text)}<br><small style="opacity:0.6; font-size:10px">${formatTime(m.ts)}</small>`
      : `<b style="color:#c084fc">${escapeHtml(m.name)}</b><br>${escapeHtml(m.text)}<br><small style="opacity:0.6; font-size:10px">${formatTime(m.ts)}</small>`;
    box.appendChild(el);
  });
  box.scrollTop = box.scrollHeight;
}

function kirimPublicMsg() {
  const input = document.getElementById('pubMsgIn');
  const text  = input.value.trim();
  if (!text) return;

  const sess = JSON.parse(localStorage.getItem('sl_session') || '{}');
  if (!sess.email) return showToast('⚠️ Login dulu!');

  const msgs = getPublicMessages();
  msgs.push({ name: sess.name, email: sess.email, text, ts: Date.now() });
  savePublicMessages(msgs);
  input.value = '';
  renderPublicChat();
}

function clearPublicChat() {
  if (!confirm('Hapus semua riwayat chat?')) return;
  localStorage.removeItem(CHAT_KEY);
  renderPublicChat();
}

function exportChat() {
  const msgs = getPublicMessages();
  if (!msgs.length) return showToast('Tidak ada pesan!');
  const text = msgs.map(m => `[${new Date(m.ts).toLocaleString('id-ID')}] ${m.name}: ${m.text}`).join('\n');
  const blob = new Blob([text], { type: 'text/plain' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = 'chat-superlock.txt'; a.click();
  URL.revokeObjectURL(url);
}

function escapeHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function formatTime(ts) {
  return new Date(ts).toLocaleString('id-ID', { hour:'2-digit', minute:'2-digit', day:'2-digit', month:'short' });
}

// Auto-refresh chat setiap 5 detik (simulasi live chat)
setInterval(() => {
  if (document.getElementById('cChat')?.classList.contains('active')) renderPublicChat();
}, 5000);

document.addEventListener('DOMContentLoaded', renderPublicChat);
