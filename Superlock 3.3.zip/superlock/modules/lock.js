// ===== ENKRIPSI / DEKRIPSI MODULE =====
let mode = 'enc';

function setMode(m) {
  mode = m;
  document.getElementById('mEnc').classList.toggle('active', m==='enc');
  document.getElementById('mDec').classList.toggle('active', m==='dec');
  document.getElementById('grpEnc').style.display = m==='enc' ? 'block' : 'none';
  document.getElementById('grpDec').style.display = m==='dec' ? 'block' : 'none';
  document.getElementById('btnLock').innerHTML = m==='enc' ? '🔒 Enkripsi' : '🔓 Dekripsi';
  document.getElementById('resBox').classList.remove('show');
}

function proses() {
  const key = document.getElementById('key').value;
  if (!key) return showToast('⚠️ Masukkan kunci rahasia!');

  const resBox = document.getElementById('resBox');
  const resContent = document.getElementById('resContent');
  resBox.classList.add('show');

  if (mode === 'enc') {
    const txt = document.getElementById('plain').value;
    if (!txt) return showToast('⚠️ Isi pesan asli!');
    const enc = CryptoJS.AES.encrypt(txt, key).toString();
    resContent.textContent = enc;
    document.getElementById('btnCpy').style.display = 'flex';
  } else {
    const encTxt = document.getElementById('enc').value;
    if (!encTxt) return showToast('⚠️ Masukkan teks terenkripsi!');
    try {
      const bytes = CryptoJS.AES.decrypt(encTxt, key);
      const dec = bytes.toString(CryptoJS.enc.Utf8);
      if (!dec) throw new Error();
      resContent.textContent = dec;
      document.getElementById('btnCpy').style.display = 'none';
      showToast('✅ Dekripsi berhasil!');
    } catch {
      resContent.textContent = '❌ Gagal! Kunci salah atau ciphertext rusak.';
    }
  }
}

function copyRes() {
  navigator.clipboard.writeText(document.getElementById('resContent').textContent);
  showToast('📋 Tersalin!');
}
