// ===== DEV TOOLS MODULE =====
let pyodideReady = false;
let pyodideInstance = null;

function switchDev(tab) {
  document.getElementById('devPy').style.display   = tab==='python' ? 'block' : 'none';
  document.getElementById('devHtml').style.display = tab==='html'   ? 'block' : 'none';
  document.getElementById('devPy').style.display   = tab==='python' ? 'block' : 'none';

  // Fix: correct element IDs for sub-nav buttons
  document.getElementById('devPy').classList.toggle('active', tab==='python');

  // Update sub-nav buttons
  document.querySelectorAll('#cDev .sub-btn').forEach((b,i) => {
    b.classList.toggle('active', (tab==='python'? i===0 : i===1));
  });

  if (tab === 'python' && !pyodideReady) initPyodide();
}

async function initPyodide() {
  const out = document.getElementById('pythonOutput');
  out.textContent = '⏳ Memuat Python (Pyodide)... Harap tunggu...';
  out.className = 'code-output';
  try {
    pyodideInstance = await loadPyodide({ indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.25.1/full/' });
    pyodideReady = true;
    out.textContent = '✅ Python siap! Tulis kode dan klik Jalankan.';
  } catch (e) {
    out.textContent = '❌ Gagal memuat Pyodide: ' + e.message;
    out.className = 'code-output error';
  }
}

async function runPython() {
  const code = document.getElementById('pythonCode').value.trim();
  const out  = document.getElementById('pythonOutput');
  const btn  = document.getElementById('pyRunBtn');

  if (!code) return showToast('⚠️ Tulis kode Python dulu!');

  if (!pyodideReady) {
    await initPyodide();
    if (!pyodideReady) return;
  }

  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Running...';
  out.className = 'code-output';
  out.textContent = '';

  try {
    // Capture stdout
    pyodideInstance.runPython(`
import sys, io
_stdout_capture = io.StringIO()
sys.stdout = _stdout_capture
`);
    pyodideInstance.runPython(code);
    const output = pyodideInstance.runPython(`
sys.stdout = sys.__stdout__
_stdout_capture.getvalue()
`);
    out.textContent = output || '(Tidak ada output)';
  } catch (e) {
    out.textContent = e.message;
    out.className = 'code-output error';
  } finally {
    btn.disabled = false;
    btn.innerHTML = '🚀 Jalankan';
  }
}

function clearPythonOutput() {
  document.getElementById('pythonOutput').textContent = '⚡ Output dihapus...';
  document.getElementById('pythonOutput').className = 'code-output';
}

function runHTML() {
  const code  = document.getElementById('htmlCode').value;
  const frame = document.getElementById('htmlOutput');
  frame.srcdoc = code;
}

// Init dev tools display
document.addEventListener('DOMContentLoaded', () => {
  // Set initial display
  const pyDiv  = document.getElementById('devPython');
  const htDiv  = document.getElementById('devHtml');
  if (pyDiv) pyDiv.style.display = 'block';
  if (htDiv) htDiv.style.display = 'none';
});
