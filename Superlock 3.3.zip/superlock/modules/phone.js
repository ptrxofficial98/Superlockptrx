// ===== VIRTUAL PHONE MODULE =====
function loadPhoneUrl() {
  const url = document.getElementById('phoneUrl').value.trim();
  if (!url) return showToast('⚠️ Masukkan URL!');

  let finalUrl = url;
  if (!url.startsWith('http')) finalUrl = 'https://' + url;

  const frame = document.getElementById('phoneFrame');
  frame.src = finalUrl;
  showToast('📱 Memuat ' + finalUrl + '...');
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('phoneUrl')?.addEventListener('keypress', e => {
    if (e.key === 'Enter') loadPhoneUrl();
  });
});
