// ===== AUTH MODULE =====
// Login & Register menggunakan localStorage (no backend needed)

function getDB() {
  return JSON.parse(localStorage.getItem('sl_users') || '{}');
}

function saveDB(db) {
  localStorage.setItem('sl_users', JSON.stringify(db));
}

function registerUser() {
  const name  = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim().toLowerCase();
  const pass  = document.getElementById('regPass').value;
  const pass2 = document.getElementById('regPass2').value;
  const err   = document.getElementById('regErr');

  if (!name || !email || !pass) return err.textContent = '⚠️ Semua field wajib diisi!';
  if (pass.length < 6)          return err.textContent = '⚠️ Password minimal 6 karakter!';
  if (pass !== pass2)           return err.textContent = '⚠️ Password tidak cocok!';
  if (!/\S+@\S+\.\S+/.test(email)) return err.textContent = '⚠️ Email tidak valid!';

  const db = getDB();
  if (db[email]) return err.textContent = '⚠️ Email sudah terdaftar!';

  const hashed = CryptoJS.SHA256(pass).toString();
  db[email] = { name, email, password: hashed, createdAt: Date.now(), wallpaper: '' };
  saveDB(db);

  err.style.color = '#4ade80';
  err.textContent = '✅ Berhasil! Silakan login.';
  setTimeout(() => { switchAuthTab('login'); err.textContent = ''; err.style.color = ''; }, 1500);
}

function loginUser() {
  const email = document.getElementById('loginEmail').value.trim().toLowerCase();
  const pass  = document.getElementById('loginPass').value;
  const err   = document.getElementById('loginErr');

  if (!email || !pass) return err.textContent = '⚠️ Isi email dan password!';

  const db = getDB();
  const user = db[email];
  if (!user) return err.textContent = '⚠️ Email tidak ditemukan!';

  const hashed = CryptoJS.SHA256(pass).toString();
  if (user.password !== hashed) return err.textContent = '⚠️ Password salah!';

  // Simpan sesi
  localStorage.setItem('sl_session', JSON.stringify({ email, name: user.name }));
  enterApp(user);
}

function logoutUser() {
  if (!confirm('Yakin mau keluar?')) return;
  localStorage.removeItem('sl_session');
  location.reload();
}

function enterApp(user) {
  document.getElementById('lockScreen').style.display = 'none';
  document.getElementById('mainApp').style.display = 'block';
  document.getElementById('userName').textContent  = user.name;
  document.getElementById('userEmail').textContent = user.email;
  document.getElementById('userAvatar').textContent = user.name[0].toUpperCase();

  // Restore wallpaper
  if (user.wallpaper) applyWallpaper(user.wallpaper);
}

function switchAuthTab(tab) {
  document.querySelectorAll('.lock-tab').forEach((t,i) => {
    t.classList.toggle('active', (tab==='login'? i===0 : i===1));
  });
  document.getElementById('loginForm').style.display    = tab==='login'    ? 'block' : 'none';
  document.getElementById('registerForm').style.display = tab==='register' ? 'block' : 'none';
  document.getElementById('loginErr').textContent = '';
  document.getElementById('regErr').textContent   = '';
}

// Cek sesi saat load
(function checkSession() {
  const sess = localStorage.getItem('sl_session');
  if (!sess) return;
  const { email } = JSON.parse(sess);
  const db = getDB();
  if (db[email]) enterApp(db[email]);
})();

// Enter key support
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('loginPass')?.addEventListener('keypress', e => { if(e.key==='Enter') loginUser(); });
  document.getElementById('regPass2')?.addEventListener('keypress', e => { if(e.key==='Enter') registerUser(); });
});
