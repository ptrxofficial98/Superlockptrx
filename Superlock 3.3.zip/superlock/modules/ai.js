// ===== AI CHAT MODULE =====
const AI_API = 'https://panelnya.online/v1/chat/completions';
let aiHistory = [];

async function kirimAI() {
  const input  = document.getElementById('aiIn');
  const model  = document.getElementById('aiModel').value;
  const system = document.getElementById('aiSystem').value.trim();
  const msg    = input.value.trim();
  if (!msg) return;

  input.value = '';
  input.style.height = 'auto';

  addChatMsg('user', msg);
  aiHistory.push({ role: 'user', content: msg });

  const typingEl = addChatMsg('ai', '<span class="spinner"></span> Mengetik...');

  try {
    const body = {
      model,
      max_tokens: 1000,
      messages: aiHistory,
    };
    if (system) body.system = system;

    const res  = await fetch(AI_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData?.error?.message || `HTTP ${res.status}`);
    }

    const data   = await res.json();
    const reply  = data.choices?.[0]?.message?.content
                || data.content?.[0]?.text
                || '(Tidak ada respons)';

    typingEl.innerHTML = marked.parse(reply);
    aiHistory.push({ role: 'assistant', content: reply });

  } catch (err) {
    typingEl.innerHTML = `❌ Error: ${err.message}`;
    typingEl.style.color = '#f87171';
    aiHistory.pop(); // remove the user msg so they can retry
  }

  scrollChat('chatBox');
}

function addChatMsg(role, html) {
  const box = document.getElementById('chatBox');
  const el  = document.createElement('div');
  el.className = `msg msg-${role}`;
  el.innerHTML = html;
  box.appendChild(el);
  scrollChat('chatBox');
  return el;
}

function scrollChat(id) {
  const box = document.getElementById(id);
  if (box) box.scrollTop = box.scrollHeight;
}

function clearAIChat() {
  aiHistory = [];
  const box = document.getElementById('chatBox');
  box.innerHTML = '<div class="msg msg-ai">🤖 Riwayat dihapus. Tanyakan apa saja!</div>';
}

function aiKeydown(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    kirimAI();
  }
  // Auto-resize textarea
  const ta = document.getElementById('aiIn');
  setTimeout(() => {
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 120) + 'px';
  }, 0);
}
